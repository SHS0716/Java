
public class HelloJAVA {

	public static void main(String[] args) {
		System.out.print("Hello Java");
		System.out.print("Hello Java");
		System.out.print("Hello Java");
	
	}
	
}
