import java.util.ArrayList;

public class Ex {

	public static void main(String[] args) {
	
//		int [] data = new int[15];
//		for (int i = 0; i < data.length; i++) {
//			data[i] = i + 1;
//		}
//		for (int i =0; i < data.length; i++) {
//			System.out.println("data[" + i + "] = " + data[i]);
//		}
		
		String [] data2 = new String[10];
		for (int i = 0; i < data2.length; i++) {
			data2[i] = ;
		}
		for (int i = 0; i< data2.length; i++) {
			System.out.println("data[" + i + "] = " + data2[i]);
		}
		
		
		
		ArrayList<Integer> list = new ArrayList<Integer>();
	}

}
