package com.koreait.memoList;

import java.lang.reflect.WildcardType;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MemoVo {
	
	public static int count;
	private int idx;			// 글번호, 자동증가
	private String name;		// 이름
	private String password;	// 비밀번호
	private String memo;			// 메모
	private Date writeDate;		// 작성일, 현재 날짜 자동입력
	
	public MemoVo() {
		this("없음", "없음", "없음");
	}

	public MemoVo(String name, String password, String memo) {
		super();
		idx = ++count;
		this.name = name;
		this.password = password;
		this.memo = memo;
		writeDate = new Date();
	}

	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}

	@Override
	public String toString() {
//		오늘 입력된 글은 시간만 표시하고 어제 이전에 입력된 글은 날짜만 표시한다.
		Date date = new Date();		// 오늘
//		오늘 작성된 글인가 비교한다.
		SimpleDateFormat sdf = null;
		if(date.getYear() == writeDate.getYear() && date.getMonth() == writeDate.getMonth()) {
			sdf = new SimpleDateFormat("HH:mm:ss");
		}else {
			sdf = new SimpleDateFormat("yyyy.MM.dd(E)");
		}
		return idx + ". " + name + "(" + password + ")님이 " + sdf.format(writeDate) + "에 남긴글\n" + memo; 
		
	}
	
	
	
	
	
}
