package kr.koreait.dbTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLConnectionTest2 {

	public static void main(String[] args) {
		
//		데이터베이스 작업에 사용할 객체를 선언한다.
		Connection conn = DBUtil.getMySQLConnection();		// 데이터베이스와 연결한다.
		System.out.println("연결성공 : "  + conn);
		DBUtil.close(conn);
	}

}
